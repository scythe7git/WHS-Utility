document.addEventListener("DOMContentLoaded", function() {
  updateCountdown();
  setInterval(updateCountdown, 1000); // Update every second
});

function updateCountdown() {
  var now = new Date();
  var isWednesday = now.getDay() === 3; // Wednesday is the 4th day of the week (0-indexed)
  var isWeekend = now.getDay() === 6 || now.getDay() === 0; // Saturday (6) or Sunday (0)

  var periods = [];

  if (isWednesday) {
    // Wednesday period times
    periods = [
      { name: "Period 1", time: "09:30" },
      { name: "Period 2", time: "10:20" },
      { name: "Break", time: "11:10" },
      { name: "Period 3", time: "11:30" },
      { name: "Period 4", time: "12:20" },
      { name: "Lunch", time: "13:20" },
      { name: "Period 5", time: "14:20" },
      { name: "School ends", time: "15:20" }
    ];
  } else if (isWeekend) {
    // Weekend countdown to Monday's Period 1 (8:45 AM)
    var daysUntilMonday = (1 - now.getDay() + 7) % 7; // Calculate days until Monday (1 is Monday)
    if (daysUntilMonday === 0) daysUntilMonday = 2; // If it's Saturday, skip to Monday (2 days ahead)

    var startOfNextMonday = new Date(now.getTime() + daysUntilMonday * 24 * 60 * 60 * 1000); // Add days to current date
    startOfNextMonday.setHours(8, 45, 0, 0); // Set to Monday's Period 1 (8:45 AM)
    
    var timeUntilNextPeriod1 = startOfNextMonday.getTime() - now.getTime();
    
    var hours = Math.floor(timeUntilNextPeriod1 / (1000 * 60 * 60));
    var minutes = Math.floor((timeUntilNextPeriod1 % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((timeUntilNextPeriod1 % (1000 * 60)) / 1000);

    var countdownStr = "Period 1 starts in ";
    countdownStr += hours + "h " + minutes + "m " + seconds + "s";

    document.getElementById("countdown").innerText = countdownStr;
    return; // Exit the function
  } else {
    // Regular weekday period times
    periods = [
      { name: "Period 1", time: "08:45" },
      { name: "Period 2", time: "09:40" },
      { name: "Break", time: "10:40" },
      { name: "Period 3", time: "11:00" },
      { name: "Homeroom", time: "12:00" },
      { name: "Period 4", time: "12:20" },
      { name: "Lunch", time: "13:20" },
      { name: "Period 5", time: "14:20" },
      { name: "School ends", time: "15:20" }
    ];
  }

  var nextPeriod = null;

  // Find the next period
  for (var i = 0; i < periods.length; i++) {
    var periodTime = new Date(now.toDateString() + " " + periods[i].time);
    if (periodTime.getTime() > now.getTime()) {
      nextPeriod = periods[i];
      break;
    }
  }

  if (nextPeriod) {
    var timeDiff = new Date(now.toDateString() + " " + nextPeriod.time).getTime() - now.getTime();
    var hours = Math.floor(timeDiff / (1000 * 60 * 60));
    var minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);

    var countdownStr = "";
    if (nextPeriod.name === "School ends") {
      countdownStr = "School ending in ";
    } else {
      countdownStr = nextPeriod.name + " starts in ";
    }
    countdownStr += hours + "h " + minutes + "m " + seconds + "s";

    document.getElementById("countdown").innerText = countdownStr;
  } else {
    // If no next period is found, reset the countdown to the start of Period 1 for the next school day
    var startOfNextDay = new Date(now);
    startOfNextDay.setDate(startOfNextDay.getDate() + 1); // Set to next day
    startOfNextDay.setHours(8, 45, 0, 0); // Set to start of Period 1
    var timeUntilNextPeriod1 = startOfNextDay.getTime() - now.getTime();

    var hours = Math.floor(timeUntilNextPeriod1 / (1000 * 60 * 60));
    var minutes = Math.floor((timeUntilNextPeriod1 % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((timeUntilNextPeriod1 % (1000 * 60)) / 1000);

    var countdownStr = "Period 1 starts in ";
    countdownStr += hours + "h " + minutes + "m " + seconds + "s";

    document.getElementById("countdown").innerText = countdownStr;
  }
}
